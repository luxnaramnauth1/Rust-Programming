# Data Engineering Mini Projects (React)

Four small, self-contained React apps that teach core data engineering ideas. Everything runs in the browser, so there is no backend to set up. All projects share one intentionally dirty `orders` dataset (missing emails, negative quantities, inconsistent country codes, duplicate rows).

## Run it

Requires Node.js 18+.

```bash
npm install
npm run dev        # open the printed local URL
npm run build      # production build into dist/
```

## The projects

| # | Project | Data engineering concept | File |
|---|---------|--------------------------|------|
| 1 | **CSV Profiler** | Data profiling and cleaning: types, nulls, uniques, min/max/mean, trim, dedupe, fill, export | `src/projects/CsvProfiler.jsx` |
| 2 | **ETL Pipeline** | Extract, Transform, Load: toggle and reorder pure transform steps, see rows per stage, simulated load | `src/projects/EtlPipeline.jsx` |
| 3 | **Data Quality** | Validation rules (not null, unique, range, regex), pass rates, failing rows, quality score | `src/projects/DataQuality.jsx` |
| 4 | **SQL Playground** | A mini SQL engine: SELECT, WHERE, GROUP BY, COUNT/SUM/AVG/MIN/MAX, ORDER BY, LIMIT | `src/lib/sql.js` |

Shared helpers: `src/lib/csv.js` (parser and writer), `src/lib/stats.js` (profiling), `src/lib/sampleData.js` (dataset).

## What each one teaches

1. **Profiling** is always step one of a pipeline. Know your nulls and types before you transform.
2. **ETL steps are pure functions** (rows in, rows out), which makes them testable. Order changes results: dedupe before trimming misses `"Asha"` vs `"  Asha"`.
3. **Data quality rules** are the same idea as Great Expectations or dbt tests, just smaller.
4. **SQL engines** parse, filter, group, aggregate, sort and limit, in that order.

## Ideas to extend (good for a portfolio)

- Add a bar chart of orders per country (plain SVG or a library such as Recharts).
- Persist pipelines and rules to `localStorage` and make them importable and exportable as JSON.
- Add JOINs to the SQL engine with a second `customers` table.
- Add a "data drift" view comparing two uploaded CSVs.
- Replace the in-browser data with a small API (FastAPI or Express) backed by SQLite or DuckDB.
- Write unit tests for `sql.js` and the ETL steps with Vitest.

## Resume bullets

- Built four React data-engineering tools (profiling, ETL simulation, data-quality validation, SQL engine) with no backend dependencies.
- Implemented a SQL subset parser and executor (filter, group, aggregate, sort) in JavaScript.
- Designed composable, pure transform steps with per-stage row-count observability.
