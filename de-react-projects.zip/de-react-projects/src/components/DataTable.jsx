export default function DataTable({ columns, rows, limit = 10, highlight }) {
  const shown = rows.slice(0, limit);
  return (
    <div className="tablewrap">
      <table>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {shown.map((r, i) => (
            <tr key={i}>
              {columns.map((c) => {
                const v = r[c];
                let content;
                if (v === null || v === undefined) content = <span className="null">NULL</span>;
                else if (v === "") content = <span className="null">empty</span>;
                else content = String(v);
                return (
                  <td key={c} className={c === highlight ? "hl" : undefined}>
                    {content}
                  </td>
                );
              })}
            </tr>
          ))}
          {!shown.length && (
            <tr>
              <td colSpan={Math.max(columns.length, 1)} className="muted">
                No rows
              </td>
            </tr>
          )}
        </tbody>
      </table>
      {rows.length > limit && (
        <p className="muted small">
          Showing {limit} of {rows.length} rows
        </p>
      )}
    </div>
  );
}
