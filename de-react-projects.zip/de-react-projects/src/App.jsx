import { useState } from "react";
import CsvProfiler from "./projects/CsvProfiler.jsx";
import EtlPipeline from "./projects/EtlPipeline.jsx";
import DataQuality from "./projects/DataQuality.jsx";
import QueryPlayground from "./projects/QueryPlayground.jsx";

const PROJECTS = [
  {
    id: "profile",
    title: "1. CSV Profiler",
    concept: "Data profiling and cleaning",
    blurb:
      "Upload a CSV (or use the sample) to see types, nulls, unique counts and statistics per column, then clean it and download the result.",
    View: CsvProfiler,
  },
  {
    id: "etl",
    title: "2. ETL Pipeline",
    concept: "Extract, Transform, Load",
    blurb:
      "Turn transform steps on and off, reorder them, and watch the row count change at every stage. Order matters.",
    View: EtlPipeline,
  },
  {
    id: "quality",
    title: "3. Data Quality",
    concept: "Validation rules and data contracts",
    blurb:
      "Define rules (not null, range, regex, unique), run them against the data, and inspect the failing rows.",
    View: DataQuality,
  },
  {
    id: "sql",
    title: "4. SQL Playground",
    concept: "Querying and aggregation",
    blurb:
      "A tiny SQL engine written in JavaScript: SELECT, WHERE, GROUP BY, aggregates, ORDER BY and LIMIT.",
    View: QueryPlayground,
  },
];

export default function App() {
  const [active, setActive] = useState(PROJECTS[0].id);
  const project = PROJECTS.find((p) => p.id === active);
  const { View } = project;

  return (
    <div className="app">
      <header>
        <h1>Data Engineering Mini Projects</h1>
        <p className="muted">
          Four small React apps. All data stays in your browser.
        </p>
      </header>

      <nav className="tabs" role="tablist">
        {PROJECTS.map((p) => (
          <button
            key={p.id}
            role="tab"
            aria-selected={p.id === active}
            className={p.id === active ? "tab active" : "tab"}
            onClick={() => setActive(p.id)}
          >
            {p.title}
          </button>
        ))}
      </nav>

      <section className="intro">
        <span className="pill">{project.concept}</span>
        <p>{project.blurb}</p>
      </section>

      <main>
        <View />
      </main>
    </div>
  );
}
