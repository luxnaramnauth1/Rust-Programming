import { useMemo, useState } from "react";
import DataTable from "../components/DataTable.jsx";
import { isMissing } from "../lib/stats.js";
import { ORDER_COLUMNS, sampleRows } from "../lib/sampleData.js";

const PRESET = [
  { id: 1, col: "order_id", type: "unique" },
  { id: 2, col: "email", type: "notnull" },
  { id: 3, col: "qty", type: "range", min: 1, max: 100 },
  { id: 4, col: "country", type: "regex", pattern: "^[A-Z]{2}$" },
  { id: 5, col: "order_date", type: "regex", pattern: "^\\d{4}-\\d{2}-\\d{2}$" },
];

function describe(r) {
  switch (r.type) {
    case "notnull": return `${r.col} must not be empty`;
    case "unique": return `${r.col} must be unique`;
    case "range": return `${r.col} must be between ${r.min} and ${r.max}`;
    case "regex": return `${r.col} must match /${r.pattern}/`;
    default: return r.col;
  }
}

// Returns { failing: number[] (row indexes), error?: string }
function evaluate(rule, rows) {
  const failing = [];
  if (rule.type === "notnull") {
    rows.forEach((row, i) => isMissing(row[rule.col]) && failing.push(i));
  } else if (rule.type === "range") {
    rows.forEach((row, i) => {
      const v = row[rule.col];
      const n = Number(v);
      if (isMissing(v) || Number.isNaN(n) || n < rule.min || n > rule.max) failing.push(i);
    });
  } else if (rule.type === "regex") {
    let re;
    try {
      re = new RegExp(rule.pattern);
    } catch (e) {
      return { failing, error: "Invalid regular expression" };
    }
    rows.forEach((row, i) => !re.test(String(row[rule.col])) && failing.push(i));
  } else if (rule.type === "unique") {
    const counts = new Map();
    rows.forEach((row) => counts.set(row[rule.col], (counts.get(row[rule.col]) || 0) + 1));
    rows.forEach((row, i) => counts.get(row[rule.col]) > 1 && failing.push(i));
  }
  return { failing };
}

export default function DataQuality() {
  const [rules, setRules] = useState(PRESET);
  const [open, setOpen] = useState(null);
  const [draft, setDraft] = useState({ col: "qty", type: "notnull", min: 0, max: 100, pattern: "" });

  const results = useMemo(
    () =>
      rules.map((r) => {
        const { failing, error } = evaluate(r, sampleRows);
        const rate = error ? 0 : 1 - failing.length / sampleRows.length;
        return { rule: r, failing, error, rate };
      }),
    [rules]
  );
  const score = results.length
    ? (results.reduce((a, r) => a + r.rate, 0) / results.length) * 100
    : 100;

  function addRule(e) {
    e.preventDefault();
    const rule = { id: Date.now(), col: draft.col, type: draft.type };
    if (draft.type === "range") {
      rule.min = Number(draft.min);
      rule.max = Number(draft.max);
    }
    if (draft.type === "regex") rule.pattern = draft.pattern;
    setRules((rs) => [...rs, rule]);
  }

  return (
    <div className="stack">
      <div className="card row">
        <div className="score">
          <div className="score-num">{score.toFixed(1)}%</div>
          <div className="muted small">overall quality score</div>
        </div>
        <div className="grow muted small">
          Score is the average pass rate across rules, evaluated on {sampleRows.length} rows.
        </div>
      </div>

      <div className="card">
        <h3>Rules</h3>
        {results.map(({ rule, failing, error, rate }) => (
          <div key={rule.id} className="rule">
            <div className="row">
              <span className={failing.length === 0 && !error ? "pill good" : "pill bad"}>
                {error ? "error" : failing.length === 0 ? "pass" : `${failing.length} failing`}
              </span>
              <span className="grow">{describe(rule)}</span>
              <span className="small">{(rate * 100).toFixed(0)}%</span>
              {failing.length > 0 && (
                <button
                  className="btn ghost"
                  onClick={() => setOpen(open === rule.id ? null : rule.id)}
                >
                  {open === rule.id ? "Hide" : "Show"} rows
                </button>
              )}
              <button
                className="btn ghost"
                aria-label={`Delete rule ${describe(rule)}`}
                onClick={() => setRules((rs) => rs.filter((x) => x.id !== rule.id))}
              >
                ✕
              </button>
            </div>
            {error && <p className="neg small">{error}</p>}
            {open === rule.id && (
              <DataTable
                columns={ORDER_COLUMNS}
                rows={failing.map((i) => sampleRows[i])}
                limit={6}
                highlight={rule.col}
              />
            )}
          </div>
        ))}
        {!results.length && <p className="muted">No rules yet. Add one below.</p>}
      </div>

      <form className="card row wrap" onSubmit={addRule}>
        <strong>Add rule</strong>
        <select value={draft.col} onChange={(e) => setDraft({ ...draft, col: e.target.value })} aria-label="Column">
          {ORDER_COLUMNS.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select value={draft.type} onChange={(e) => setDraft({ ...draft, type: e.target.value })} aria-label="Rule type">
          <option value="notnull">not null</option>
          <option value="unique">unique</option>
          <option value="range">range</option>
          <option value="regex">regex</option>
        </select>
        {draft.type === "range" && (
          <>
            <input type="number" value={draft.min} onChange={(e) => setDraft({ ...draft, min: e.target.value })} aria-label="Minimum" />
            <input type="number" value={draft.max} onChange={(e) => setDraft({ ...draft, max: e.target.value })} aria-label="Maximum" />
          </>
        )}
        {draft.type === "regex" && (
          <input
            placeholder="^[A-Z]{2}$"
            value={draft.pattern}
            onChange={(e) => setDraft({ ...draft, pattern: e.target.value })}
            aria-label="Pattern"
          />
        )}
        <button className="btn primary" type="submit">Add</button>
      </form>
    </div>
  );
}
