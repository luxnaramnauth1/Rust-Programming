import { useMemo, useState } from "react";
import DataTable from "../components/DataTable.jsx";
import { toCSV } from "../lib/csv.js";
import { dedupe, isMissing, mapValues } from "../lib/stats.js";
import { ORDER_COLUMNS, sampleRows } from "../lib/sampleData.js";
import { downloadText } from "../lib/download.js";

// Each step is a pure function: rows in, rows out.
const STEP_DEFS = {
  trim: {
    label: "Trim whitespace",
    run: (rows) => rows.map((r) => mapValues(r, (v) => String(v).trim())),
  },
  country: {
    label: "Uppercase country codes",
    run: (rows) => rows.map((r) => ({ ...r, country: String(r.country).toUpperCase() })),
  },
  dedupe: {
    label: "Remove duplicate rows",
    run: (rows, cols) => dedupe(rows, cols),
  },
  email: {
    label: "Drop rows with missing email",
    run: (rows) => rows.filter((r) => !isMissing(r.email)),
  },
  qty: {
    label: "Drop invalid quantity (<= 0)",
    run: (rows) => rows.filter((r) => Number(r.qty) > 0),
  },
  revenue: {
    label: "Add revenue column (qty x price)",
    addsColumn: "revenue",
    run: (rows) =>
      rows.map((r) => ({ ...r, revenue: String(Number(r.qty) * Number(r.price)) })),
  },
};

const INITIAL = ["trim", "country", "dedupe", "email", "qty", "revenue"].map((id) => ({
  id,
  on: true,
}));

export default function EtlPipeline() {
  const [steps, setSteps] = useState(INITIAL);
  const [loaded, setLoaded] = useState(null);

  const run = useMemo(() => {
    let cols = ORDER_COLUMNS;
    let cur = sampleRows;
    const stages = [{ label: "Extract (source)", count: cur.length, removed: 0, ms: 0 }];
    for (const s of steps) {
      if (!s.on) continue;
      const def = STEP_DEFS[s.id];
      const t0 = performance.now();
      const next = def.run(cur, cols);
      const ms = performance.now() - t0;
      if (def.addsColumn && !cols.includes(def.addsColumn)) cols = [...cols, def.addsColumn];
      stages.push({ label: def.label, count: next.length, removed: cur.length - next.length, ms });
      cur = next;
    }
    return { stages, rows: cur, columns: cols };
  }, [steps]);

  const max = Math.max(...run.stages.map((s) => s.count), 1);

  const toggle = (i) =>
    setSteps((s) => s.map((x, j) => (j === i ? { ...x, on: !x.on } : x)));
  const move = (i, d) =>
    setSteps((s) => {
      const j = i + d;
      if (j < 0 || j >= s.length) return s;
      const c = [...s];
      [c[i], c[j]] = [c[j], c[i]];
      return c;
    });

  return (
    <div className="stack">
      <div className="card">
        <h3>Transform steps</h3>
        <p className="muted small">
          Try moving "Remove duplicate rows" above "Trim whitespace" and watch what is missed.
        </p>
        <ul className="steps">
          {steps.map((s, i) => (
            <li key={s.id} className={s.on ? "" : "off"}>
              <label>
                <input type="checkbox" checked={s.on} onChange={() => toggle(i)} />{" "}
                {STEP_DEFS[s.id].label}
              </label>
              <span className="row">
                <button className="btn ghost" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move up">↑</button>
                <button className="btn ghost" onClick={() => move(i, 1)} disabled={i === steps.length - 1} aria-label="Move down">↓</button>
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="card">
        <h3>Rows at each stage</h3>
        {run.stages.map((s, i) => (
          <div key={i} className="stage">
            <div className="stage-label small">{s.label}</div>
            <div className="meter wide">
              <div className="meter-fill" style={{ width: `${(s.count / max) * 100}%` }} />
            </div>
            <div className="stage-num small">
              {s.count}
              {s.removed > 0 && <span className="neg"> (-{s.removed})</span>}
            </div>
          </div>
        ))}
        <div className="row wrap top-gap">
          <button
            className="btn primary"
            onClick={() =>
              setLoaded({
                rows: run.rows.length,
                at: new Date().toLocaleTimeString(),
              })
            }
          >
            Load into warehouse
          </button>
          <button
            className="btn"
            onClick={() => downloadText("orders_clean.csv", toCSV(run.columns, run.rows))}
          >
            Download output CSV
          </button>
        </div>
        {loaded && (
          <p className="ok small" role="status">
            [{loaded.at}] Loaded {loaded.rows} rows into analytics.orders_clean (simulated).
          </p>
        )}
      </div>

      <div className="card">
        <h3>Output preview</h3>
        <DataTable columns={run.columns} rows={run.rows} limit={8} />
      </div>
    </div>
  );
}
