import { useMemo, useState } from "react";
import DataTable from "../components/DataTable.jsx";
import { parseCSV, toCSV } from "../lib/csv.js";
import { dedupe, fmt, isMissing, mapValues, profile } from "../lib/stats.js";
import { ORDER_COLUMNS, sampleRows } from "../lib/sampleData.js";
import { downloadText } from "../lib/download.js";

export default function CsvProfiler() {
  const [data, setData] = useState({
    name: "sample_orders.csv",
    columns: ORDER_COLUMNS,
    rows: sampleRows,
  });
  const [note, setNote] = useState("");

  const prof = useMemo(() => profile(data.columns, data.rows), [data]);
  const totalNulls = prof.reduce((a, p) => a + p.nulls, 0);

  function onFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const parsed = parseCSV(String(reader.result));
      setData({ name: file.name, ...parsed });
      setNote(`Loaded ${file.name}: ${parsed.rows.length} rows, ${parsed.columns.length} columns.`);
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  function apply(label, fn) {
    setData((d) => {
      const rows = fn(d);
      setNote(`${label}: ${d.rows.length} -> ${rows.length} rows.`);
      return { ...d, rows };
    });
  }

  const actions = [
    {
      label: "Trim whitespace",
      fn: (d) => d.rows.map((r) => mapValues(r, (v) => String(v).trim())),
    },
    { label: "Remove duplicates", fn: (d) => dedupe(d.rows, d.columns) },
    {
      label: "Fill missing values",
      fn: (d) => {
        const fills = Object.fromEntries(
          profile(d.columns, d.rows).map((p) => [
            p.col,
            p.type === "number" && p.mean !== undefined ? String(Math.round(p.mean * 100) / 100) : "unknown",
          ])
        );
        return d.rows.map((r) =>
          Object.fromEntries(d.columns.map((c) => [c, isMissing(r[c]) ? fills[c] : r[c]]))
        );
      },
    },
  ];

  return (
    <div className="stack">
      <div className="card row">
        <div className="grow">
          <strong>{data.name}</strong>
          <div className="muted small">
            {data.rows.length} rows · {data.columns.length} columns · {totalNulls} missing cells
          </div>
        </div>
        <label className="btn">
          Upload CSV
          <input type="file" accept=".csv,text/csv" onChange={onFile} hidden />
        </label>
        <button
          className="btn ghost"
          onClick={() => {
            setData({ name: "sample_orders.csv", columns: ORDER_COLUMNS, rows: sampleRows });
            setNote("Reset to the sample dataset.");
          }}
        >
          Reset sample
        </button>
      </div>

      <div className="card">
        <h3>Clean</h3>
        <div className="row wrap">
          {actions.map((a) => (
            <button key={a.label} className="btn" onClick={() => apply(a.label, a.fn)}>
              {a.label}
            </button>
          ))}
          <button
            className="btn primary"
            onClick={() => downloadText("cleaned_" + data.name, toCSV(data.columns, data.rows))}
          >
            Download CSV
          </button>
        </div>
        {note && <p className="muted small" role="status">{note}</p>}
      </div>

      <div className="card">
        <h3>Column profile</h3>
        <div className="tablewrap">
          <table>
            <thead>
              <tr>
                <th>Column</th>
                <th>Type</th>
                <th>Missing</th>
                <th>Unique</th>
                <th>Min</th>
                <th>Max</th>
                <th>Mean</th>
                <th>Top values</th>
              </tr>
            </thead>
            <tbody>
              {prof.map((p) => {
                const pct = p.total ? (p.nulls / p.total) * 100 : 0;
                return (
                  <tr key={p.col}>
                    <td><strong>{p.col}</strong></td>
                    <td><span className="pill">{p.type}</span></td>
                    <td>
                      <div className="meter" title={`${pct.toFixed(0)}% missing`}>
                        <div className="meter-fill warn" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="small">{p.nulls} ({pct.toFixed(0)}%)</span>
                    </td>
                    <td>{p.unique}</td>
                    <td>{fmt(p.min)}</td>
                    <td>{fmt(p.max)}</td>
                    <td>{fmt(p.mean)}</td>
                    <td className="small">
                      {p.top.map(([v, n]) => `${String(v).trim() || "(blank)"} ×${n}`).join(", ")}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h3>Preview</h3>
        <DataTable columns={data.columns} rows={data.rows} limit={8} />
      </div>
    </div>
  );
}
