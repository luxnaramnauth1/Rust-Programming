import { useMemo, useState } from "react";
import DataTable from "../components/DataTable.jsx";
import { coerce, runQuery } from "../lib/sql.js";
import { ORDER_COLUMNS, sampleRows } from "../lib/sampleData.js";

const EXAMPLES = [
  {
    label: "Revenue-ish by country",
    sql: "SELECT country, COUNT(*) AS orders, SUM(qty) AS units, AVG(price) AS avg_price\nFROM orders\nGROUP BY country\nORDER BY units DESC",
  },
  {
    label: "Big laptop orders",
    sql: "SELECT order_id, customer, qty, price\nFROM orders\nWHERE product = 'Laptop' AND qty >= 3\nORDER BY qty DESC\nLIMIT 5",
  },
  {
    label: "Find missing emails",
    sql: "SELECT order_id, customer, email FROM orders WHERE email IS NULL",
  },
  {
    label: "Customers starting with A",
    sql: "SELECT customer, COUNT(*) AS n FROM orders WHERE customer LIKE 'A%' GROUP BY customer",
  },
];

export default function QueryPlayground() {
  const tables = useMemo(
    () => ({
      orders: {
        columns: ORDER_COLUMNS,
        rows: sampleRows.map((r) =>
          Object.fromEntries(ORDER_COLUMNS.map((c) => [c, coerce(r[c])]))
        ),
      },
    }),
    []
  );

  const [sql, setSql] = useState(EXAMPLES[0].sql);
  const [state, setState] = useState(() => exec(EXAMPLES[0].sql));

  function exec(q) {
    const t0 = performance.now();
    try {
      const result = runQuery(q, tables);
      return { result, ms: performance.now() - t0 };
    } catch (e) {
      return { error: e.message };
    }
  }

  const run = (q = sql) => setState(exec(q));

  return (
    <div className="stack">
      <div className="card">
        <h3>Table: orders</h3>
        <p className="muted small">{ORDER_COLUMNS.join(", ")}</p>
        <div className="row wrap">
          {EXAMPLES.map((ex) => (
            <button
              key={ex.label}
              className="btn ghost"
              onClick={() => {
                setSql(ex.sql);
                run(ex.sql);
              }}
            >
              {ex.label}
            </button>
          ))}
        </div>
        <textarea
          value={sql}
          onChange={(e) => setSql(e.target.value)}
          onKeyDown={(e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === "Enter") run();
          }}
          rows={6}
          spellCheck={false}
          aria-label="SQL query"
        />
        <div className="row">
          <button className="btn primary" onClick={() => run()}>Run (Ctrl+Enter)</button>
          {state.result && (
            <span className="muted small" role="status">
              {state.result.rows.length} rows in {state.ms.toFixed(1)} ms
            </span>
          )}
        </div>
      </div>

      <div className="card">
        <h3>Result</h3>
        {state.error ? (
          <p className="neg" role="alert">{state.error}</p>
        ) : (
          <DataTable columns={state.result.columns} rows={state.result.rows} limit={20} />
        )}
      </div>
    </div>
  );
}
